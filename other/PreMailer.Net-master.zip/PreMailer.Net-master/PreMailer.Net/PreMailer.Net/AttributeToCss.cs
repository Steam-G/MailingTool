namespace PreMailer.Net
{
    public class AttributeToCss
    {
        public string AttributeName { get; set; }
        public string CssValue { get; set; }
    }
}